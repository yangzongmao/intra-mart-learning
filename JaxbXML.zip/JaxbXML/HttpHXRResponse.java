package com.lakala.payment.app.web.servlet;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;

import com.lakala.payment.app.web.common.exception.MultiPaymentException;

import nablarch.fw.web.HttpResponse;
import net.arnx.jsonic.JSON;
import net.arnx.jsonic.JSONException;

/**
 * HTTPレスポンスメッセージを生成する際に必要な情報を格納したクラス。
 *
 * @author Lakala Japan
 * @since 1.0
 */
public class HttpHXRResponse extends HttpResponse {
    /**
     * コンストラクター
     */
    public HttpHXRResponse(Object obj) {
        super();
        try {
            this.setStatusCode(200);
            this.setHeader("Content-Type", "application/json;charset=utf-8");
            this.setHeader("Cache-Control", "no-cache");
            this.setHeader("Pragma", "no-cache");
            this.setBodyStream(new ByteArrayInputStream(JSON.encode(obj).getBytes(Charset.forName("UTF-8"))));
        } catch (JSONException e) {
            throw new MultiPaymentException(e);
        }
    }
}
