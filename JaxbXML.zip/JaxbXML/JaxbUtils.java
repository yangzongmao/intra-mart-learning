package com.lakala.payment.app.gateway.kddi.util;

import java.io.ByteArrayInputStream;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 * モデルとXMLの変換クラス
 *
 * @author Huxm
 */
public class JaxbUtils {

    public static String toXml(Object object) {

        String dataXml = "";
        try {
            if (object != null) {
                JAXBContext cxt = JAXBContext.newInstance(object.getClass());
                Marshaller marshaller = cxt.createMarshaller();
                marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
                marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, false);
                marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

                StringWriter sw = new StringWriter();
                marshaller.marshal(object, sw);
                dataXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + sw.toString().replaceAll("&lt;", "<").replaceAll("&gt;", ">") + "\r\n\r\n";
            }
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return dataXml;
    }

    @SuppressWarnings("unchecked")
    public static <T> T toDto(String xml, Class<T> clazz) {
        try {
            ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
            JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
            Unmarshaller u = jaxbContext.createUnmarshaller();
            return (T) u.unmarshal(is);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
