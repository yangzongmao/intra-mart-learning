import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name = "xmlRoot")
@XmlAccessorType(XmlAccessType.FIELD)
public class KddiPayReqDto implements Serializable {

    /**
     * シーケンス番号
     */
    private String seqNo;

    /**
     * ワンタイムコード
     */
    private String onetmCd;

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getOnetmCd() {
        return onetmCd;
    }

    public void setOnetmCd(String onetmCd) {
        this.onetmCd = onetmCd;
    }
}
