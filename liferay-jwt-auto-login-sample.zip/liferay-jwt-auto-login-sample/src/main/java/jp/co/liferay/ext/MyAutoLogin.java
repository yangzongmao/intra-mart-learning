package jp.co.liferay.ext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.model.CompanyConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.security.auto.login.AutoLogin;
import com.liferay.portal.kernel.security.auto.login.AutoLoginException;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import jp.co.liferay.ext.utils.JwtUtil;

public class MyAutoLogin implements AutoLogin {
    private static Log LGOGER = LogFactoryUtil.getLog(MyAutoLogin.class);

    // @Override
    public String[] login(HttpServletRequest request, HttpServletResponse response) throws AutoLoginException {
        String token = ParamUtil.getString(request, "token");

        // トークンnullチェック
        if (Validator.isNull(token)) {
            LGOGER.error("token is null.");
            return null;
        }

        // ログインID取得
        String loginId = JwtUtil.getUsername(token);
        if (Validator.isNull(loginId)) {
            LGOGER.error("loginId is null.");
            return null;
        }

        // トークン検証
        if (!JwtUtil.verify(token, loginId, "1234567890123456")) {
            LGOGER.error("token is invalid.");
            return null;
        }

        try {
            Company company = PortalUtil.getCompany(request);
            String authType = company.getAuthType();

            long userId = 0;
            if (authType.equals(CompanyConstants.AUTH_TYPE_EA)) {
                userId = UserLocalServiceUtil.getUserIdByEmailAddress(company.getCompanyId(), loginId);
            } else if (authType.equals(CompanyConstants.AUTH_TYPE_SN)) {
                userId = UserLocalServiceUtil.getUserIdByScreenName(company.getCompanyId(), loginId);
            } else if (authType.equals(CompanyConstants.AUTH_TYPE_ID)) {
                userId = GetterUtil.getLong(loginId);
            } else {
                return null;
            }
            User user = UserLocalServiceUtil.getUserById(userId);
            String[] credentials = new String[] { String.valueOf(user.getUserId()), user.getPassword(), String.valueOf(user.isPasswordEncrypted()) };
            LGOGER.error("automatic login was successful. loginId:[" + loginId + "]");
            return credentials;
        } catch (Exception e) {
            LGOGER.error("automatic login exception :", e);
        }
        LGOGER.error("automatic login failed. token:[" + token + "]");
        return null;
    }
}
