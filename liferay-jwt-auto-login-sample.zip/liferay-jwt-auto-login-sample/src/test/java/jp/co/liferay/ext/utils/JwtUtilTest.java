package jp.co.liferay.ext.utils;

import org.junit.Test;

public class JwtUtilTest {

    @Test
    public void testSign() throws InterruptedException {
        String secret = "1234567890123456";

        String token = JwtUtil.sign("test", secret);
        System.out.println(token);

//        String userName = JwtUtil.getUsername(token);
//        System.out.println(userName);
//
//        boolean result = JwtUtil.verify(token, userName, secret);
//        System.out.println(result);
    }
}
